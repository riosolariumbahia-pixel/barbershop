
"use client";
import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function Home(){
  const [data,setData]=useState<any[]>([]);

  useEffect(()=>{fetchData()},[]);

  async function fetchData(){
    const { data } = await supabase.from("appointments").select("*");
    setData(data||[]);
  }

  return(
    <div style={{padding:20}}>
      <h1>🚀 BarberFlow Pro</h1>
      <p>Dashboard conectado ao Supabase</p>
      <ul>
        {data.map(item=>(
          <li key={item.id}>💰 R$ {item.price}</li>
        ))}
      </ul>
    </div>
  )
}
