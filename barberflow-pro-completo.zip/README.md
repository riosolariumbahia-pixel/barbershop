
# BarberFlow Pro (Pronto para Vercel)

## Instalar
npm install

## Rodar
npm run dev

## Deploy
Suba no GitHub → importe na Vercel

## .env
Copie .env.example para .env.local e preencha
