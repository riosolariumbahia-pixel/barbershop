# BarberFlow Pro

Projeto SaaS inicial conectado ao Supabase.

## Rodar

npm install
npm run dev

## Deploy

Suba no Vercel
