
"use client";

import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  "https://hmodjesdlgevednosnkv.supabase.co",
  "YOUR_ANON_KEY"
);

export default function Home() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const { data } = await supabase.from("appointments").select("*");
    setData(data || []);
  }

  return (
    <div style={{background:'#000',color:'#fff',minHeight:'100vh',padding:20}}>
      <h1>BarberFlow Pro</h1>
      <ul>
        {data.map((item:any)=> (
          <li key={item.id}>💰 R$ {item.price}</li>
        ))}
      </ul>
    </div>
  );
}
