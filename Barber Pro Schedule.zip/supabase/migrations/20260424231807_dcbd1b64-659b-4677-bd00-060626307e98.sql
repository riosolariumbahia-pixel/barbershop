CREATE OR REPLACE FUNCTION public.upsert_public_client(
  _barbershop_id uuid,
  _name text,
  _phone text,
  _email text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _client_id uuid;
BEGIN
  -- Try find existing
  SELECT id INTO _client_id
  FROM public.clients
  WHERE barbershop_id = _barbershop_id AND phone = _phone
  LIMIT 1;

  IF _client_id IS NOT NULL THEN
    RETURN _client_id;
  END IF;

  INSERT INTO public.clients (barbershop_id, name, phone, email)
  VALUES (_barbershop_id, _name, _phone, _email)
  RETURNING id INTO _client_id;

  RETURN _client_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.upsert_public_client(uuid, text, text, text) TO anon, authenticated;