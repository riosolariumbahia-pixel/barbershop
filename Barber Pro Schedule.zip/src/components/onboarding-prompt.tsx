import { useState } from "react";
import { Scissors } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { slugify } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export function OnboardingPrompt({ onCreated }: { onCreated: () => void }) {
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const finalSlug = (slug || slugify(name)).trim();
    if (!finalSlug) {
      toast.error("Defina um identificador para o link público.");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("barbershops").insert({
      owner_id: user.id,
      name: name.trim(),
      slug: finalSlug,
      phone: phone.trim() || null,
      address: address.trim() || null,
      description: description.trim() || null,
    });
    setSubmitting(false);
    if (error) {
      toast.error(error.message.includes("duplicate") ? "Esse link já está em uso. Escolha outro." : error.message);
      return;
    }
    toast.success("Barbearia criada! Vamos lá.");
    onCreated();
  };

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <div className="h-14 w-14 rounded-2xl bg-gradient-gold flex items-center justify-center mx-auto mb-4 shadow-gold">
          <Scissors className="h-7 w-7 text-primary-foreground" />
        </div>
        <h1 className="font-display text-3xl font-bold mb-2">Configure sua barbearia</h1>
        <p className="text-muted-foreground">Leva menos de 1 minuto. Você pode editar depois.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-card border border-border/50 rounded-2xl p-8 space-y-5 shadow-elegant">
        <div>
          <Label htmlFor="name">Nome da barbearia *</Label>
          <Input
            id="name"
            required
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              if (!slug) setSlug(slugify(e.target.value));
            }}
            placeholder="Ex: Barbearia do João"
          />
        </div>
        <div>
          <Label htmlFor="slug">Link público *</Label>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground whitespace-nowrap">/</span>
            <Input
              id="slug"
              required
              value={slug}
              onChange={(e) => setSlug(slugify(e.target.value))}
              placeholder="barbearia-joao"
            />
            <span className="text-sm text-muted-foreground whitespace-nowrap">/agendar</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">Apenas letras, números e hífens.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="phone">Telefone</Label>
            <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="(11) 99999-9999" />
          </div>
          <div>
            <Label htmlFor="address">Endereço</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Rua, número, bairro" />
          </div>
        </div>
        <div>
          <Label htmlFor="description">Descrição (opcional)</Label>
          <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Conte um pouco sobre sua barbearia..." />
        </div>
        <Button
          type="submit"
          className="w-full bg-gradient-gold text-primary-foreground hover:opacity-90 shadow-gold"
          disabled={submitting || !name}
        >
          {submitting ? "Criando..." : "Criar barbearia"}
        </Button>
      </form>
    </div>
  );
}
