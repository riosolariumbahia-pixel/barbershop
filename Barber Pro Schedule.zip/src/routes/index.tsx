import { createFileRoute, Link } from "@tanstack/react-router";
import { Scissors, Calendar, Users, BarChart3, CheckCircle2, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BarberPro — Sistema de Gestão para Barbearias" },
      { name: "description", content: "Agendamento online, gestão de equipe, clientes e relatórios em uma única plataforma. Comece grátis." },
      { property: "og:title", content: "BarberPro — Gestão completa para sua barbearia" },
      { property: "og:description", content: "Agendamento online, gestão de equipe, clientes e relatórios em uma única plataforma." },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-md sticky top-0 z-50 bg-background/70">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-lg bg-gradient-gold flex items-center justify-center shadow-gold">
              <Scissors className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold">BarberPro</span>
          </Link>
          <nav className="flex items-center gap-3">
            <Link to="/auth">
              <Button variant="ghost" size="sm">Entrar</Button>
            </Link>
            <Link to="/auth">
              <Button size="sm" className="bg-gradient-gold text-primary-foreground hover:opacity-90 shadow-gold">
                Começar grátis
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/5 mb-8">
            <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-medium text-primary">Gestão completa para barbearias modernas</span>
          </div>
          <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-6">
            Sua barbearia,<br />
            <span className="bg-gradient-gold bg-clip-text text-transparent">100% no controle.</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
            Agendamentos online, equipe, clientes e relatórios financeiros — tudo em uma plataforma feita para barbearias premium.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/auth">
              <Button size="lg" className="bg-gradient-gold text-primary-foreground hover:opacity-90 shadow-gold text-base px-8">
                Criar conta grátis
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-base px-8" asChild>
              <a href="#recursos">Ver recursos</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="recursos" className="container mx-auto px-4 py-20 border-t border-border/50">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
            Tudo o que você precisa
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Recursos pensados para o dia-a-dia de barbearias profissionais.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {[
            { icon: Calendar, title: "Agenda inteligente", desc: "Cada barbeiro com sua agenda. Combos com cálculo automático de duração." },
            { icon: Users, title: "Gestão de clientes", desc: "Histórico, preferências e fidelização — tudo em um só lugar." },
            { icon: BarChart3, title: "Relatórios em tempo real", desc: "Faturamento, comissões, ocupação e desempenho da equipe." },
          ].map((f) => (
            <div key={f.title} className="p-8 rounded-2xl bg-card border border-border/50 hover:border-primary/30 transition-colors group">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                <f.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-display text-xl font-bold mb-2">{f.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto rounded-3xl bg-card border border-primary/20 p-12 text-center shadow-elegant">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Pronto para profissionalizar sua barbearia?
          </h2>
          <p className="text-muted-foreground mb-8">
            Configure sua barbearia em menos de 5 minutos. Sem cartão de crédito.
          </p>
          <ul className="flex flex-wrap gap-x-8 gap-y-3 justify-center text-sm mb-8">
            {["Agendamento online", "Link público exclusivo", "Sem mensalidade no início"].map((item) => (
              <li key={item} className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                {item}
              </li>
            ))}
          </ul>
          <Link to="/auth">
            <Button size="lg" className="bg-gradient-gold text-primary-foreground hover:opacity-90 shadow-gold px-8">
              Criar minha conta
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} BarberPro. Feito para barbearias premium.
      </footer>
    </div>
  );
}
