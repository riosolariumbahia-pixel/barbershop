import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Users } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop } from "@/lib/use-barbershop";
import { Input } from "@/components/ui/input";
import { OnboardingPrompt } from "@/components/onboarding-prompt";
import { EmptyState } from "./_app.servicos";

export const Route = createFileRoute("/_app/clientes")({
  component: ClientsPage,
});

interface Client {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  created_at: string;
}

function ClientsPage() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [items, setItems] = useState<Client[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!barbershop) return;
    (async () => {
      const { data } = await supabase.from("clients").select("*").eq("barbershop_id", barbershop.id).order("created_at", { ascending: false });
      setItems((data ?? []) as Client[]);
    })();
  }, [barbershop?.id]);

  if (loading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (!barbershop) return <OnboardingPrompt onCreated={refetch} />;

  const filtered = items.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search) ||
    (c.email?.toLowerCase().includes(search.toLowerCase()) ?? false)
  );

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold">Clientes</h1>
        <p className="text-muted-foreground mt-1">Cadastrados via página pública de agendamento</p>
      </div>

      <Input
        placeholder="Buscar por nome, telefone ou e-mail..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-6 max-w-md"
      />

      {items.length === 0 ? (
        <EmptyState icon={Users} title="Ainda sem clientes" desc="Quando alguém agendar pelo seu link público, aparecerá aqui." />
      ) : (
        <div className="bg-card border border-border/50 rounded-xl overflow-hidden">
          <table className="w-full">
            <thead className="bg-secondary/30 border-b border-border/50">
              <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Telefone</th>
                <th className="px-4 py-3 font-medium hidden md:table-cell">E-mail</th>
                <th className="px-4 py-3 font-medium hidden md:table-cell">Cadastro</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id} className="border-b border-border/30 last:border-0 hover:bg-secondary/20">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.phone}</td>
                  <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{c.email ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground text-sm hidden md:table-cell">{format(new Date(c.created_at), "dd/MM/yyyy", { locale: ptBR })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
