import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Copy, Download, ExternalLink } from "lucide-react";
import { QRCodeCanvas } from "qrcode.react";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop, slugify } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { OnboardingPrompt } from "@/components/onboarding-prompt";

export const Route = createFileRoute("/_app/barbearia")({
  component: BarbershopSettingsPage,
});

function BarbershopSettingsPage() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const qrRef = useRef<HTMLCanvasElement>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(bookingUrl);
    toast.success("Link copiado!");
  };

  const handleDownloadQR = () => {
    const canvas = qrRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.href = url;
    link.download = `qrcode-${barbershop?.slug ?? "agendamento"}.png`;
    link.click();
    toast.success("QR Code baixado!");
  };

  useEffect(() => {
    if (barbershop) {
      setName(barbershop.name);
      setSlug(barbershop.slug);
      setPhone(barbershop.phone ?? "");
      setAddress(barbershop.address ?? "");
      setDescription(barbershop.description ?? "");
    }
  }, [barbershop?.id]);

  if (loading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (!barbershop) return <OnboardingPrompt onCreated={refetch} />;

  const bookingUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/${slug}/agendar`;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("barbershops").update({
      name: name.trim(),
      slug: slugify(slug),
      phone: phone.trim() || null,
      address: address.trim() || null,
      description: description.trim() || null,
    }).eq("id", barbershop.id);
    setSaving(false);
    if (error) { toast.error(error.message.includes("duplicate") ? "Esse link já está em uso" : error.message); return; }
    toast.success("Barbearia atualizada");
    refetch();
  };

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold">Configurações da Barbearia</h1>
        <p className="text-muted-foreground mt-1">Edite os dados públicos da sua barbearia</p>
      </div>

      <div className="bg-card border border-primary/20 rounded-2xl p-6 mb-6 shadow-gold">
        <p className="text-xs uppercase tracking-wide text-primary mb-4 text-center">QR Code de agendamento</p>
        <div className="flex flex-col items-center gap-4">
          <div className="bg-white p-4 rounded-xl shadow-lg">
            <QRCodeCanvas
              ref={qrRef}
              value={bookingUrl}
              size={200}
              level="H"
              includeMargin={false}
            />
          </div>
          <code className="w-full text-sm bg-background/50 px-3 py-2 rounded-md truncate text-center">{bookingUrl}</code>
          <div className="flex flex-wrap gap-2 justify-center w-full">
            <Button variant="outline" size="sm" onClick={handleCopy}>
              <Copy className="h-4 w-4 mr-2" /> Copiar link
            </Button>
            <Button variant="outline" size="sm" onClick={handleDownloadQR}>
              <Download className="h-4 w-4 mr-2" /> Baixar QR Code
            </Button>
            <a href={bookingUrl} target="_blank" rel="noreferrer">
              <Button variant="outline" size="sm">
                <ExternalLink className="h-4 w-4 mr-2" /> Abrir
              </Button>
            </a>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="bg-card border border-border/50 rounded-2xl p-8 space-y-5">
        <div>
          <Label htmlFor="name">Nome *</Label>
          <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <Label htmlFor="slug">Identificador do link</Label>
          <Input id="slug" required value={slug} onChange={(e) => setSlug(slugify(e.target.value))} />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="phone">Telefone</Label>
            <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="address">Endereço</Label>
            <Input id="address" value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
        </div>
        <div>
          <Label htmlFor="description">Descrição</Label>
          <Textarea id="description" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <Button type="submit" className="w-full bg-gradient-gold text-primary-foreground shadow-gold" disabled={saving}>
          {saving ? "Salvando..." : "Salvar alterações"}
        </Button>
      </form>
    </div>
  );
}
