import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Calendar, DollarSign, Users, TrendingUp, ExternalLink, Copy } from "lucide-react";
import { format, startOfDay, endOfDay, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { OnboardingPrompt } from "@/components/onboarding-prompt";

export const Route = createFileRoute("/_app/dashboard")({
  component: Dashboard,
});

interface Stats {
  todayCount: number;
  todayRevenue: number;
  monthCount: number;
  monthRevenue: number;
  clientCount: number;
}

function Dashboard() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [stats, setStats] = useState<Stats>({ todayCount: 0, todayRevenue: 0, monthCount: 0, monthRevenue: 0, clientCount: 0 });
  const [upcoming, setUpcoming] = useState<any[]>([]);

  useEffect(() => {
    if (!barbershop) return;
    (async () => {
      const now = new Date();
      const todayStart = startOfDay(now).toISOString();
      const todayEnd = endOfDay(now).toISOString();
      const monthStart = startOfMonth(now).toISOString();
      const monthEnd = endOfMonth(now).toISOString();

      const [todayRes, monthRes, clientRes, upcomingRes] = await Promise.all([
        supabase.from("appointments").select("price").eq("barbershop_id", barbershop.id).gte("scheduled_at", todayStart).lte("scheduled_at", todayEnd).neq("status", "cancelled"),
        supabase.from("appointments").select("price").eq("barbershop_id", barbershop.id).gte("scheduled_at", monthStart).lte("scheduled_at", monthEnd).neq("status", "cancelled"),
        supabase.from("clients").select("id", { count: "exact", head: true }).eq("barbershop_id", barbershop.id),
        supabase.from("appointments").select("*, clients(name), professionals(name), services(name)").eq("barbershop_id", barbershop.id).gte("scheduled_at", now.toISOString()).neq("status", "cancelled").order("scheduled_at").limit(5),
      ]);

      setStats({
        todayCount: todayRes.data?.length ?? 0,
        todayRevenue: (todayRes.data ?? []).reduce((s, a) => s + Number(a.price), 0),
        monthCount: monthRes.data?.length ?? 0,
        monthRevenue: (monthRes.data ?? []).reduce((s, a) => s + Number(a.price), 0),
        clientCount: clientRes.count ?? 0,
      });
      setUpcoming(upcomingRes.data ?? []);
    })();
  }, [barbershop?.id]);

  if (loading) {
    return <div className="p-8"><div className="h-6 w-32 bg-muted rounded animate-pulse" /></div>;
  }

  if (!barbershop) {
    return <OnboardingPrompt onCreated={refetch} />;
  }

  const bookingUrl = `${typeof window !== "undefined" ? window.location.origin : ""}/${barbershop.slug}/agendar`;

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold">Olá, {barbershop.name}</h1>
          <p className="text-muted-foreground mt-1">{format(new Date(), "EEEE, d 'de' MMMM", { locale: ptBR })}</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              navigator.clipboard.writeText(bookingUrl);
              toast.success("Link copiado!");
            }}
          >
            <Copy className="h-4 w-4 mr-2" />
            Copiar link de agendamento
          </Button>
          <a href={bookingUrl} target="_blank" rel="noreferrer">
            <Button size="sm" className="bg-gradient-gold text-primary-foreground hover:opacity-90 shadow-gold">
              <ExternalLink className="h-4 w-4 mr-2" />
              Abrir página pública
            </Button>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Calendar} label="Agendamentos hoje" value={stats.todayCount.toString()} />
        <StatCard icon={DollarSign} label="Receita hoje" value={`R$ ${stats.todayRevenue.toFixed(2)}`} />
        <StatCard icon={TrendingUp} label="Receita do mês" value={`R$ ${stats.monthRevenue.toFixed(2)}`} highlight />
        <StatCard icon={Users} label="Clientes cadastrados" value={stats.clientCount.toString()} />
      </div>

      <div className="bg-card border border-border/50 rounded-2xl p-6">
        <h2 className="font-display text-xl font-bold mb-4">Próximos agendamentos</h2>
        {upcoming.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">
            Nenhum agendamento futuro. Compartilhe seu link de agendamento para começar.
          </p>
        ) : (
          <div className="space-y-3">
            {upcoming.map((a) => (
              <div key={a.id} className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 border border-border/30">
                <div>
                  <p className="font-medium">{a.clients?.name}</p>
                  <p className="text-sm text-muted-foreground">{a.services?.name} • {a.professionals?.name}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-primary">{format(new Date(a.scheduled_at), "dd/MM 'às' HH:mm", { locale: ptBR })}</p>
                  <p className="text-xs text-muted-foreground">R$ {Number(a.price).toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="mt-4 text-right">
          <Link to="/agenda">
            <Button variant="ghost" size="sm">Ver agenda completa →</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, highlight }: { icon: any; label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`rounded-2xl p-5 border ${highlight ? "bg-gradient-gold border-primary/30 text-primary-foreground shadow-gold" : "bg-card border-border/50"}`}>
      <div className="flex items-center justify-between mb-3">
        <Icon className={`h-5 w-5 ${highlight ? "" : "text-muted-foreground"}`} />
      </div>
      <p className={`text-2xl font-bold font-display ${highlight ? "" : ""}`}>{value}</p>
      <p className={`text-xs mt-1 ${highlight ? "opacity-80" : "text-muted-foreground"}`}>{label}</p>
    </div>
  );
}
