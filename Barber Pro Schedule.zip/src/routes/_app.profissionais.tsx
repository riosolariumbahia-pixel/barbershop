import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, UserCog } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { OnboardingPrompt } from "@/components/onboarding-prompt";
import { EmptyState } from "./_app.servicos";

export const Route = createFileRoute("/_app/profissionais")({
  component: ProfessionalsPage,
});

interface Professional {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  specialties: string[];
  commission_percent: number;
  active: boolean;
}

function ProfessionalsPage() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [items, setItems] = useState<Professional[]>([]);
  const [editing, setEditing] = useState<Professional | null>(null);
  const [open, setOpen] = useState(false);

  const load = async () => {
    if (!barbershop) return;
    const { data } = await supabase.from("professionals").select("*").eq("barbershop_id", barbershop.id).order("created_at", { ascending: false });
    setItems((data ?? []) as Professional[]);
  };
  useEffect(() => { load(); }, [barbershop?.id]);

  if (loading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (!barbershop) return <OnboardingPrompt onCreated={refetch} />;

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const specialties = String(fd.get("specialties") || "")
      .split(",").map((s) => s.trim()).filter(Boolean);
    const payload = {
      barbershop_id: barbershop.id,
      name: String(fd.get("name")),
      email: String(fd.get("email") || "") || null,
      phone: String(fd.get("phone") || "") || null,
      specialties,
      commission_percent: Number(fd.get("commission") || 0),
      active: true,
    };

    const { error } = editing
      ? await supabase.from("professionals").update(payload).eq("id", editing.id)
      : await supabase.from("professionals").insert(payload);

    if (error) { toast.error(error.message); return; }
    toast.success(editing ? "Profissional atualizado" : "Profissional cadastrado");
    setOpen(false); setEditing(null); load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir este profissional?")) return;
    const { error } = await supabase.from("professionals").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Profissional excluído"); load();
  };

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold">Profissionais</h1>
          <p className="text-muted-foreground mt-1">Sua equipe de barbeiros</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditing(null); }}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-gold text-primary-foreground shadow-gold">
              <Plus className="h-4 w-4 mr-2" /> Novo profissional
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editing ? "Editar" : "Novo"} profissional</DialogTitle></DialogHeader>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome *</Label>
                <Input id="name" name="name" required defaultValue={editing?.name} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" name="email" type="email" defaultValue={editing?.email ?? ""} />
                </div>
                <div>
                  <Label htmlFor="phone">Telefone</Label>
                  <Input id="phone" name="phone" defaultValue={editing?.phone ?? ""} />
                </div>
              </div>
              <div>
                <Label htmlFor="specialties">Especialidades (separadas por vírgula)</Label>
                <Input id="specialties" name="specialties" placeholder="fade, barba, coloração" defaultValue={editing?.specialties.join(", ") ?? ""} />
              </div>
              <div>
                <Label htmlFor="commission">Comissão (%)</Label>
                <Input id="commission" name="commission" type="number" min="0" max="100" step="1" defaultValue={editing?.commission_percent ?? 0} />
              </div>
              <Button type="submit" className="w-full bg-gradient-gold text-primary-foreground">Salvar</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {items.length === 0 ? (
        <EmptyState icon={UserCog} title="Nenhum profissional cadastrado" desc="Adicione barbeiros à sua equipe para começar a receber agendamentos." />
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {items.map((p) => (
            <div key={p.id} className="bg-card border border-border/50 rounded-xl p-5 hover:border-primary/30 transition-colors">
              <div className="flex justify-between items-start gap-3">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className="h-12 w-12 rounded-full bg-gradient-gold flex items-center justify-center font-bold text-primary-foreground shrink-0">
                    {p.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold truncate">{p.name}</h3>
                    {p.phone && <p className="text-xs text-muted-foreground">{p.phone}</p>}
                    {p.specialties.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {p.specialties.map((s) => (
                          <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary">{s}</span>
                        ))}
                      </div>
                    )}
                    {p.commission_percent > 0 && (
                      <p className="text-xs text-muted-foreground mt-2">Comissão: {p.commission_percent}%</p>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(p); setOpen(true); }}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(p.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
