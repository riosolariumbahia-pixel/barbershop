import { createFileRoute, useParams, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Scissors, Clock, Check, ArrowLeft, MapPin, Phone } from "lucide-react";
import { format, addDays, startOfDay, endOfDay, addMinutes, isAfter, isBefore } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/$slug/agendar")({
  component: BookingPage,
});

interface Barbershop {
  id: string;
  name: string;
  slug: string;
  phone: string | null;
  address: string | null;
  description: string | null;
}
interface Service { id: string; name: string; price: number; duration_minutes: number; category: string; description: string | null; }
interface Professional { id: string; name: string; specialties: string[]; }

const HOURS = Array.from({ length: 12 }, (_, i) => 9 + i); // 9h - 20h
const SLOT_MINUTES = 30;

function BookingPage() {
  const { slug } = useParams({ from: "/$slug/agendar" });
  const [step, setStep] = useState<1 | 2 | 3 | 4 | "done">(1);
  const [shop, setShop] = useState<Barbershop | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [pros, setPros] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedPro, setSelectedPro] = useState<Professional | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date>(addDays(new Date(), 0));
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [busySlots, setBusySlots] = useState<{ start: Date; end: Date }[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: shopData } = await supabase.from("barbershops").select("*").eq("slug", slug).maybeSingle();
      if (!shopData) { setNotFound(true); setLoading(false); return; }
      setShop(shopData as Barbershop);
      const [{ data: svc }, { data: pr }] = await Promise.all([
        supabase.from("services").select("*").eq("barbershop_id", shopData.id).eq("active", true).order("price"),
        supabase.from("professionals").select("*").eq("barbershop_id", shopData.id).eq("active", true).order("name"),
      ]);
      setServices((svc ?? []) as Service[]);
      setPros((pr ?? []) as Professional[]);
      setLoading(false);
    })();
  }, [slug]);

  // Load busy slots when professional + date selected
  useEffect(() => {
    if (!selectedPro || !shop) return;
    (async () => {
      const { data } = await supabase
        .from("appointments")
        .select("scheduled_at, end_at")
        .eq("professional_id", selectedPro.id)
        .neq("status", "cancelled")
        .gte("scheduled_at", startOfDay(selectedDate).toISOString())
        .lte("scheduled_at", endOfDay(selectedDate).toISOString());
      setBusySlots((data ?? []).map((a: any) => ({ start: new Date(a.scheduled_at), end: new Date(a.end_at) })));
    })();
  }, [selectedPro?.id, selectedDate.toDateString(), shop?.id]);

  const availableSlots = useMemo(() => {
    if (!selectedService) return [];
    const slots: Date[] = [];
    const now = new Date();
    for (const h of HOURS) {
      for (let m = 0; m < 60; m += SLOT_MINUTES) {
        const slot = new Date(selectedDate);
        slot.setHours(h, m, 0, 0);
        if (isBefore(slot, now)) continue;
        const end = addMinutes(slot, selectedService.duration_minutes);
        const conflict = busySlots.some((b) => isBefore(slot, b.end) && isAfter(end, b.start));
        if (!conflict) slots.push(slot);
      }
    }
    return slots;
  }, [selectedDate, selectedService?.duration_minutes, busySlots]);

  const handleConfirm = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!shop || !selectedService || !selectedPro || !selectedTime) return;
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name")).trim();
    const phone = String(fd.get("phone")).trim();
    const email = String(fd.get("email") || "").trim() || null;
    if (!name || !phone) { toast.error("Preencha nome e telefone"); return; }

    setSubmitting(true);

    // create or fetch client via RPC (bypasses public read restriction)
    const { data: clientId, error: cErr } = await supabase.rpc("upsert_public_client", {
      _barbershop_id: shop.id,
      _name: name,
      _phone: phone,
      _email: email ?? undefined,
    });
    if (cErr || !clientId) {
      toast.error(cErr?.message ?? "Não foi possível registrar seus dados. Tente novamente.");
      setSubmitting(false);
      return;
    }

    const scheduled = new Date(selectedTime);
    const end = addMinutes(scheduled, selectedService.duration_minutes);

    const { error: aErr } = await supabase.from("appointments").insert({
      barbershop_id: shop.id,
      client_id: clientId,
      professional_id: selectedPro.id,
      service_id: selectedService.id,
      scheduled_at: scheduled.toISOString(),
      duration_minutes: selectedService.duration_minutes,
      end_at: end.toISOString(),
      price: selectedService.price,
      status: "confirmed",
    });

    setSubmitting(false);
    if (aErr) { toast.error(aErr.message); return; }
    setStep("done");
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-gradient-dark"><div className="h-8 w-8 rounded-full border-2 border-primary border-t-transparent animate-spin" /></div>;
  if (notFound) return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-dark px-4">
      <div className="text-center">
        <h1 className="font-display text-4xl font-bold mb-2">Barbearia não encontrada</h1>
        <p className="text-muted-foreground mb-6">Verifique o link e tente novamente.</p>
        <Link to="/"><Button variant="outline">Ir ao início</Button></Link>
      </div>
    </div>
  );
  if (!shop) return null;

  return (
    <div className="min-h-screen bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-md bg-background/70">
        <div className="container mx-auto px-4 py-6 max-w-3xl">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-gradient-gold flex items-center justify-center shadow-gold">
              <Scissors className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold">{shop.name}</h1>
              {shop.address && <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="h-3 w-3" />{shop.address}</p>}
            </div>
          </div>
          {shop.description && <p className="text-sm text-muted-foreground mt-3">{shop.description}</p>}
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-3xl">
        {step === "done" ? (
          <div className="bg-card border border-primary/30 rounded-2xl p-10 text-center shadow-elegant">
            <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
              <Check className="h-8 w-8 text-primary" />
            </div>
            <h2 className="font-display text-3xl font-bold mb-2">Agendamento confirmado!</h2>
            <p className="text-muted-foreground mb-6">
              {selectedService?.name} com {selectedPro?.name}<br />
              <span className="text-foreground font-medium">{selectedTime && format(new Date(selectedTime), "EEEE, d 'de' MMMM 'às' HH:mm", { locale: ptBR })}</span>
            </p>
            <Button onClick={() => { setStep(1); setSelectedService(null); setSelectedPro(null); setSelectedTime(null); }} variant="outline">
              Fazer outro agendamento
            </Button>
          </div>
        ) : (
          <>
            {/* Step indicator */}
            <div className="flex items-center justify-between mb-8">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className={cn(
                  "flex-1 h-1 rounded-full mx-1",
                  n <= step ? "bg-primary" : "bg-secondary"
                )} />
              ))}
            </div>

            {step > 1 && (
              <Button variant="ghost" size="sm" className="mb-4" onClick={() => setStep((step - 1) as any)}>
                <ArrowLeft className="h-4 w-4 mr-2" /> Voltar
              </Button>
            )}

            {step === 1 && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-2">Escolha o serviço</h2>
                <p className="text-muted-foreground text-sm mb-6">Selecione o serviço que deseja agendar.</p>
                {services.length === 0 ? (
                  <div className="bg-card border border-border/50 rounded-xl p-8 text-center text-muted-foreground">Esta barbearia ainda não cadastrou serviços.</div>
                ) : (
                  <div className="space-y-3">
                    {services.map((s) => (
                      <button
                        key={s.id}
                        onClick={() => { setSelectedService(s); setStep(2); }}
                        className="w-full bg-card border border-border/50 rounded-xl p-5 hover:border-primary/50 transition-colors text-left flex justify-between items-center group"
                      >
                        <div>
                          <p className="font-bold">{s.name}</p>
                          {s.description && <p className="text-sm text-muted-foreground mt-0.5">{s.description}</p>}
                          <p className="text-xs text-muted-foreground flex items-center gap-1 mt-2"><Clock className="h-3 w-3" />{s.duration_minutes}min</p>
                        </div>
                        <span className="font-display text-xl font-bold text-primary">R$ {Number(s.price).toFixed(2)}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-2">Escolha o profissional</h2>
                <p className="text-muted-foreground text-sm mb-6">Quem irá te atender?</p>
                {pros.length === 0 ? (
                  <div className="bg-card border border-border/50 rounded-xl p-8 text-center text-muted-foreground">Esta barbearia ainda não cadastrou profissionais.</div>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-3">
                    {pros.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => { setSelectedPro(p); setStep(3); }}
                        className="bg-card border border-border/50 rounded-xl p-5 hover:border-primary/50 transition-colors text-left flex items-center gap-3"
                      >
                        <div className="h-12 w-12 rounded-full bg-gradient-gold flex items-center justify-center font-bold text-primary-foreground">
                          {p.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold truncate">{p.name}</p>
                          {p.specialties.length > 0 && (
                            <p className="text-xs text-muted-foreground truncate">{p.specialties.join(" • ")}</p>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-2">Escolha o horário</h2>
                <p className="text-muted-foreground text-sm mb-6">Disponibilidade de {selectedPro?.name}</p>

                <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                  {Array.from({ length: 14 }).map((_, i) => {
                    const d = addDays(new Date(), i);
                    const active = d.toDateString() === selectedDate.toDateString();
                    return (
                      <button
                        key={i}
                        onClick={() => { setSelectedDate(d); setSelectedTime(null); }}
                        className={cn(
                          "flex flex-col items-center justify-center min-w-[60px] py-2 px-3 rounded-lg border transition-colors",
                          active ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border/50 hover:border-primary/30"
                        )}
                      >
                        <span className="text-[10px] uppercase">{format(d, "EEE", { locale: ptBR })}</span>
                        <span className="font-bold text-lg">{format(d, "d")}</span>
                      </button>
                    );
                  })}
                </div>

                {availableSlots.length === 0 ? (
                  <div className="bg-card border border-border/50 rounded-xl p-8 text-center text-muted-foreground">Nenhum horário disponível neste dia.</div>
                ) : (
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                    {availableSlots.map((s) => {
                      const iso = s.toISOString();
                      const active = selectedTime === iso;
                      return (
                        <button
                          key={iso}
                          onClick={() => { setSelectedTime(iso); setStep(4); }}
                          className={cn(
                            "py-3 rounded-lg border text-sm font-medium transition-colors",
                            active ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border/50 hover:border-primary/50"
                          )}
                        >
                          {format(s, "HH:mm")}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {step === 4 && (
              <div>
                <h2 className="font-display text-2xl font-bold mb-2">Seus dados</h2>
                <p className="text-muted-foreground text-sm mb-6">Para confirmar o agendamento</p>

                <div className="bg-card border border-primary/20 rounded-xl p-5 mb-6">
                  <p className="text-xs uppercase tracking-wide text-primary mb-2">Resumo</p>
                  <p className="font-bold">{selectedService?.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedPro?.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedTime && format(new Date(selectedTime), "EEEE, d 'de' MMMM 'às' HH:mm", { locale: ptBR })}</p>
                  <p className="font-display text-xl font-bold text-primary mt-2">R$ {selectedService && Number(selectedService.price).toFixed(2)}</p>
                </div>

                <form onSubmit={handleConfirm} className="bg-card border border-border/50 rounded-xl p-6 space-y-4">
                  <div>
                    <Label htmlFor="name">Nome completo *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="phone">Telefone (WhatsApp) *</Label>
                    <Input id="phone" name="phone" required placeholder="(11) 99999-9999" />
                  </div>
                  <div>
                    <Label htmlFor="email">E-mail (opcional)</Label>
                    <Input id="email" name="email" type="email" />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-gold text-primary-foreground shadow-gold" disabled={submitting}>
                    {submitting ? "Confirmando..." : "Confirmar agendamento"}
                  </Button>
                </form>
              </div>
            )}
          </>
        )}
      </main>

      <footer className="text-center py-8 text-xs text-muted-foreground">
        {shop.phone && <p className="flex items-center justify-center gap-1"><Phone className="h-3 w-3" />{shop.phone}</p>}
        <p className="mt-2">Powered by <Link to="/" className="text-primary hover:underline">BarberPro</Link></p>
      </footer>
    </div>
  );
}
