import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Calendar as CalIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { format, addDays, startOfDay, endOfDay, isToday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { OnboardingPrompt } from "@/components/onboarding-prompt";
import { EmptyState } from "./_app.servicos";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_app/agenda")({
  component: AgendaPage,
});

interface Appointment {
  id: string;
  scheduled_at: string;
  duration_minutes: number;
  end_at: string;
  price: number;
  status: string;
  notes: string | null;
  client_id: string;
  professional_id: string;
  service_id: string;
  clients: { name: string; phone: string } | null;
  professionals: { name: string } | null;
  services: { name: string } | null;
}

function AgendaPage() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [date, setDate] = useState<Date>(new Date());
  const [items, setItems] = useState<Appointment[]>([]);

  const load = async () => {
    if (!barbershop) return;
    const { data } = await supabase
      .from("appointments")
      .select("*, clients(name, phone), professionals(name), services(name)")
      .eq("barbershop_id", barbershop.id)
      .gte("scheduled_at", startOfDay(date).toISOString())
      .lte("scheduled_at", endOfDay(date).toISOString())
      .order("scheduled_at");
    setItems((data ?? []) as unknown as Appointment[]);
  };

  useEffect(() => { load(); }, [barbershop?.id, date.toDateString()]);

  if (loading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (!barbershop) return <OnboardingPrompt onCreated={refetch} />;

  const updateStatus = async (id: string, status: "confirmed" | "completed" | "cancelled" | "no_show" | "pending") => {
    const { error } = await supabase.from("appointments").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Agendamento atualizado");
    load();
  };

  const cancelApt = async (id: string) => {
    if (!confirm("Cancelar este agendamento?")) return;
    await updateStatus(id, "cancelled");
  };

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold">Agenda</h1>
          <p className="text-muted-foreground mt-1 capitalize">
            {format(date, "EEEE, d 'de' MMMM", { locale: ptBR })}
            {isToday(date) && <span className="ml-2 text-primary">• Hoje</span>}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setDate(addDays(date, -1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => setDate(new Date())}>Hoje</Button>
          <Button variant="outline" size="icon" onClick={() => setDate(addDays(date, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState icon={CalIcon} title="Nenhum agendamento neste dia" desc="Quando clientes agendarem, eles aparecerão aqui ordenados por horário." />
      ) : (
        <div className="space-y-3">
          {items.map((a) => (
            <div
              key={a.id}
              className={`bg-card border rounded-xl p-5 flex flex-col md:flex-row md:items-center gap-4 ${
                a.status === "cancelled" ? "border-border/30 opacity-50" : "border-border/50 hover:border-primary/30"
              } transition-colors`}
            >
              <div className="text-center min-w-[80px]">
                <div className="font-display text-2xl font-bold text-primary">{format(new Date(a.scheduled_at), "HH:mm")}</div>
                <div className="text-xs text-muted-foreground">{a.duration_minutes}min</div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold">{a.clients?.name}</p>
                <p className="text-sm text-muted-foreground">{a.services?.name} • {a.professionals?.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{a.clients?.phone}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold text-primary">R$ {Number(a.price).toFixed(2)}</span>
                <Select value={a.status} onValueChange={(v) => updateStatus(a.id, v as any)}>
                  <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="confirmed">Confirmado</SelectItem>
                    <SelectItem value="completed">Concluído</SelectItem>
                    <SelectItem value="cancelled">Cancelado</SelectItem>
                    <SelectItem value="no_show">Não compareceu</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="sm" variant="ghost" onClick={() => cancelApt(a.id)}>Cancelar</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
