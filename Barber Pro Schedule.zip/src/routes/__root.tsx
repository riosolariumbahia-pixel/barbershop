import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import { Toaster } from "sonner";
import { AuthProvider } from "@/lib/auth-context";
import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-primary font-display">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Página não encontrada</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A página que você procura não existe.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Voltar ao início
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "BarberPro — Sistema de Gestão para Barbearias" },
      { name: "description", content: "Plataforma completa para gestão de barbearias: agendamentos online, equipe, clientes e relatórios em tempo real." },
      { property: "og:title", content: "BarberPro — Sistema de Gestão para Barbearias" },
      { name: "twitter:title", content: "BarberPro — Sistema de Gestão para Barbearias" },
      { property: "og:description", content: "Plataforma completa para gestão de barbearias: agendamentos online, equipe, clientes e relatórios em tempo real." },
      { name: "twitter:description", content: "Plataforma completa para gestão de barbearias: agendamentos online, equipe, clientes e relatórios em tempo real." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3836801d-f6e0-4000-be89-cde652c5430e/id-preview-90460dcf--eeff2595-e1a1-4068-86b3-cd9a628af5ed.lovable.app-1776888303074.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/3836801d-f6e0-4000-be89-cde652c5430e/id-preview-90460dcf--eeff2595-e1a1-4068-86b3-cd9a628af5ed.lovable.app-1776888303074.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <AuthProvider>
      <Outlet />
      <Toaster theme="dark" position="top-right" richColors />
    </AuthProvider>
  );
}
