import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Scissors } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useMyBarbershop } from "@/lib/use-barbershop";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { OnboardingPrompt } from "@/components/onboarding-prompt";

export const Route = createFileRoute("/_app/servicos")({
  component: ServicesPage,
});

interface Service {
  id: string;
  name: string;
  description: string | null;
  price: number;
  duration_minutes: number;
  category: string;
  active: boolean;
}

const CATEGORIES = ["corte", "barba", "coloração", "hidratação", "combo", "outros"];

function ServicesPage() {
  const { barbershop, loading, refetch } = useMyBarbershop();
  const [services, setServices] = useState<Service[]>([]);
  const [editing, setEditing] = useState<Service | null>(null);
  const [open, setOpen] = useState(false);

  const load = async () => {
    if (!barbershop) return;
    const { data } = await supabase.from("services").select("*").eq("barbershop_id", barbershop.id).order("created_at", { ascending: false });
    setServices((data ?? []) as Service[]);
  };

  useEffect(() => { load(); }, [barbershop?.id]);

  if (loading) return <div className="p-8 text-muted-foreground">Carregando...</div>;
  if (!barbershop) return <OnboardingPrompt onCreated={refetch} />;

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      barbershop_id: barbershop.id,
      name: String(fd.get("name")),
      description: String(fd.get("description") || "") || null,
      price: Number(fd.get("price")),
      duration_minutes: Number(fd.get("duration")),
      category: String(fd.get("category")),
      active: true,
    };

    const { error } = editing
      ? await supabase.from("services").update(payload).eq("id", editing.id)
      : await supabase.from("services").insert(payload);

    if (error) { toast.error(error.message); return; }
    toast.success(editing ? "Serviço atualizado" : "Serviço criado");
    setOpen(false);
    setEditing(null);
    load();
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir este serviço?")) return;
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Serviço excluído");
    load();
  };

  return (
    <div className="p-6 md:p-10 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold">Serviços</h1>
          <p className="text-muted-foreground mt-1">Catálogo da sua barbearia</p>
        </div>
        <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditing(null); }}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-gold text-primary-foreground shadow-gold">
              <Plus className="h-4 w-4 mr-2" /> Novo serviço
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editing ? "Editar serviço" : "Novo serviço"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <Label htmlFor="name">Nome *</Label>
                <Input id="name" name="name" required defaultValue={editing?.name} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="price">Preço (R$) *</Label>
                  <Input id="price" name="price" type="number" step="0.01" min="0" required defaultValue={editing?.price ?? 50} />
                </div>
                <div>
                  <Label htmlFor="duration">Duração (min) *</Label>
                  <Input id="duration" name="duration" type="number" min="5" step="5" required defaultValue={editing?.duration_minutes ?? 30} />
                </div>
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select name="category" defaultValue={editing?.category ?? "corte"}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="description">Descrição</Label>
                <Textarea id="description" name="description" rows={2} defaultValue={editing?.description ?? ""} />
              </div>
              <Button type="submit" className="w-full bg-gradient-gold text-primary-foreground">Salvar</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {services.length === 0 ? (
        <EmptyState icon={Scissors} title="Nenhum serviço ainda" desc="Cadastre cortes, barbas e combos para começar a receber agendamentos." />
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {services.map((s) => (
            <div key={s.id} className="bg-card border border-border/50 rounded-xl p-5 hover:border-primary/30 transition-colors">
              <div className="flex justify-between items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold truncate">{s.name}</h3>
                    <span className="text-[10px] uppercase tracking-wide px-2 py-0.5 rounded-full bg-primary/10 text-primary">{s.category}</span>
                  </div>
                  {s.description && <p className="text-sm text-muted-foreground line-clamp-2">{s.description}</p>}
                  <div className="flex items-center gap-4 mt-3 text-sm">
                    <span className="text-primary font-semibold">R$ {Number(s.price).toFixed(2)}</span>
                    <span className="text-muted-foreground">{s.duration_minutes} min</span>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(s); setOpen(true); }}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => handleDelete(s.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function EmptyState({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="bg-card border border-dashed border-border/50 rounded-2xl p-12 text-center">
      <div className="h-12 w-12 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
        <Icon className="h-6 w-6 text-muted-foreground" />
      </div>
      <h3 className="font-bold mb-1">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-sm mx-auto">{desc}</p>
    </div>
  );
}
