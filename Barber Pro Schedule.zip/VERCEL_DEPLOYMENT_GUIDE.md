# 🚀 Guia Completo: Deploy no Vercel

Seu projeto está 100% pronto para ser publicado no Vercel! Siga estes 4 passos simples.

---

## 📋 Pré-requisitos

- ✅ Conta GitHub (já tem)
- ✅ Conta Supabase (para banco de dados)
- ✅ Conta Vercel (criar em https://vercel.com)

---

## 🔧 PASSO 1: Obter Credenciais do Supabase (2 minutos)

### 1.1 - Acesse seu Supabase
- Vá para https://supabase.com
- Faça login na sua conta
- Selecione seu projeto

### 1.2 - Copie as Credenciais
Na seção **"Settings > API"** (lado esquerdo):

1. Copie a **Project URL** (URL do seu projeto)
   - Exemplo: `https://seu-projeto.supabase.co`

2. Copie a **anon public** (chave pública)
   - Exemplo: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

**Guarde essas duas informações!** Você vai precisar no próximo passo.

---

## 🔗 PASSO 2: Conectar Repositório ao Vercel (3 minutos)

### 2.1 - Acesse Vercel
- Vá para https://vercel.com
- Clique em **"Sign Up"** (se não tem conta) ou **"Log In"**
- Escolha **"Continue with GitHub"**
- Autorize o Vercel a acessar seus repositórios

### 2.2 - Importar Projeto
1. Clique em **"Add New..."** (canto superior direito)
2. Selecione **"Project"**
3. Em "Import Git Repository", procure por `cut-time-smart`
4. Clique em **"Import"**

---

## 🔐 PASSO 3: Adicionar Variáveis de Ambiente (2 minutos)

Após clicar em "Import", você verá a página de configuração:

### 3.1 - Environment Variables
Na seção **"Environment Variables"**, adicione:

**Variável 1:**
- Name: `VITE_SUPABASE_URL`
- Value: (Cole a Project URL do Supabase)
- Clique **"Add"**

**Variável 2:**
- Name: `VITE_SUPABASE_ANON_KEY`
- Value: (Cole a anon public key do Supabase)
- Clique **"Add"**

### 3.2 - Confirme
Verifique que ambas variáveis aparecem na lista com o ícone de cadeado ✓

---

## 🚀 PASSO 4: Deploy (5 minutos)

### 4.1 - Iniciar Deploy
Clique no botão **"Deploy"** (canto inferior direito)

### 4.2 - Aguarde
O Vercel fará:
- ✓ Clone do seu repositório
- ✓ Instalação das dependências (`npm ci`)
- ✓ Build da aplicação (`npm run build`)
- ✓ Deploy automático

Isso leva entre 3-5 minutos.

### 4.3 - Sucesso! 🎉
Quando terminar, você verá uma tela como:
```
✅ Congratulations! Your project has been successfully deployed
```

E aparecerá um link como: `https://cut-time-smart-xxxxx.vercel.app`

---

## 🎯 Próximos Passos (Opcional)

### Usar Domínio Customizado
1. No Vercel, vá para "Settings" > "Domains"
2. Adicione seu domínio (ex: `barbearia.com`)
3. Configure os DNS no seu registrador

### Deploy Automático
Toda vez que você fizer `git push` para `main`, o Vercel fará deploy automático!

---

## ⚠️ Troubleshooting

### Erro: "Build Failed"
- Verifique se as variáveis de ambiente estão corretas
- Confira se o Supabase URL não tem espaços em branco
- Tente fazer rebuild (Settings > Deployments > Redeploy)

### Erro: "Cannot find module"
- Provavelmente as dependências não instalaram
- Vá para Settings > Functions > Redeploy with Cache Disabled

### App não carrega no Vercel
- Verifique console (F12) para erros
- Confirme as credenciais do Supabase
- Veja os logs em Vercel > Deployments > Logs

---

## 📞 Precisa de Ajuda?

- **Vercel Docs:** https://vercel.com/docs
- **Supabase Docs:** https://supabase.com/docs
- **TanStack Start:** https://tanstack.com/start

---

## ✅ Checklist Final

- [ ] Credenciais do Supabase copiadas
- [ ] Conta Vercel criada
- [ ] Repositório importado no Vercel
- [ ] Variáveis de ambiente adicionadas
- [ ] Deploy realizado com sucesso
- [ ] URL da aplicação funcionando

🎉 **Parabéns! Seu app está no ar!**
